const json_data = require('./userApi');

module.exports = {
  data: json_data,
};