const albumData = require('./albums');
const bandData = require('./bands');

module.exports = {
  albums: albumData,
  bands: bandData
};
