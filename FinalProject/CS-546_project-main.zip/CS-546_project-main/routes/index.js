const userRoutes = require('./users');
const messageRoutes = require('./messages');

const constructorMethod = (app) => {
  app.use('/', userRoutes);
  app.use('/', messageRoutes);

  app.use('*', (req, res) => {
    return res.render('pages/error', {title: "Error", error: "Page not found"});
  });
};

module.exports = constructorMethod;