const express = require('express');
const router = express.Router();

const data = require('../data');
const users = data.users;
const messages = data.messages;
const { ObjectId } = require('mongodb');
const { findChatroom } = require('../data/messages');
const { chatroom } = require('../config/mongoCollections');


router.route('/matches')
.get(async (req, res) => {
    try{
        //console.log(req.session.user.username);
        const userId = await users.getUserIdFromUsername(req.session.user.username);
        //console.log(userId);
        let previews = await messages.getMatchPreviews(userId);

        previews.forEach(curUser =>{
            let image_url = null;
            if(curUser.photo.image.toString() != "none") {
                image_url = "data:" + curUser.photo.contentType + ";base64," + curUser.photo.image.toString('base64');
            }
            curUser.photo = image_url;
        })

            
// let newpre = { firstName : curUser.firstName, lastName: curUser.lastName, img: image_url }

        // let newpreviews = Array.from({ length: 100 }, () => previews).flat();
        //console.log(userId)
        const userImage = await messages.getImage(userId);
        if(userImage.image.toString() != "none") {
            userImage.image = "data:" + userImage.contentType + ";base64," + userImage.image.toString('base64');
        }else{
            userImage.image = "/public/images/default.jpeg"
        }
        return res.status(200).render('pages/matches', {title: "Matches", userId:userId,  previews:previews,userImage:userImage.image, username: req.session.user.username, error: false});
    } catch (e) {
        console.error(e);
        return res.render('pages/error', {title: "Error", error: e});
    }
});

router.route('/fetchChat')
.post(async (req, res) => {
    //console.log("rendering messages")
    const userId = req.body.userId;
    const matchId = req.body.matchId;
    try{
        //console.log(userId);
        //console.log(matchId);
        let chatroomId = (await messages.findChatroom(userId, matchId)).toString();
        let chats= await messages.getMessageHistory(chatroomId);
        //console.log("rendering messages")
        //console.log(chatroomId);
        
        res.status(200).json({
            chatroomId:chatroomId,
            chats:chats
        });

        // return res.status(200).render('pages/matches', 
        //     {
        //         title: "Matches",
        //         userId:userId,
        //         chats:chats,
        //         chatroomId:chatroomId,
        //         error: false
        //     }
        // );

    }catch(e){
        console.error(e);
        return res.render('pages/error', {title: "Error", error: e});
    }
});

router.route('/sendChat')
.post(async (req, res) => {
    const message = req.body.message;
    const chatroom = req.body.chatroom;
    const senderId = req.body.userId;
    try{
        await messages.createMessage(message,chatroom,senderId);
    }catch(e){
        console.error(e);
    }
})



module.exports = router;