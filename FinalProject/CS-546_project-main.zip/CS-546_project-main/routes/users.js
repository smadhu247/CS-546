const express = require('express');
const router = express.Router();
const data = require('../data');
const userData = data.users;
const { ObjectId } = require('mongodb');
const { users } = require('../data');
const xss = require('xss');

const fs = require("fs");
const multer = require("multer");
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/");

var imgSchema = mongoose.Schema({
    img:{data:Buffer,contentType: String}
});
var image = mongoose.model("image",imgSchema); 

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
    cb(null, 'files')
    },
    filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now())
    }
})
var upload = multer({ storage: storage })

async function errorCheckLogin(username, password) {

    if(!username) throw "username parameter not provided";
    if(!password) throw "password parameter not provided";

    if(typeof username != "string") throw "username parameter is not a string";
    if(typeof password != "string") throw "password parameter is not a string";

    username = username.toLowerCase();
    username = username.trim();
    password = password.trim();

    if(username.length == 0) throw "username parameter is empty";
    if(password.length == 0) throw "password parameter is empty";

    if(username.length < 4) throw "username must be at least 4 characters long";
    if(password.length < 6) throw "password must be at least 6 characters long"; 

    if(/\s/.test(username)) throw "username should not contain spaces"
    if(/\s/.test(password)) throw "password should not contain spaces"

    var alphaNumerics = /^[0-9a-zA-Z]+$/;
    if(!username.match(alphaNumerics)) throw "username can only contain alphanumeric characters"
}

async function errorCheckSignUp(username, password, firstName, lastName, email, gender, age, city, state) {

    if(!username) throw "username parameter not provided";
    if(!password) throw "password parameter not provided";
    if(!firstName) throw "first name parameter not provided";
    if(!lastName) throw "last name parameter not provided";
    if(!email) throw "email parameter not provided";
    if(!gender) throw "gender parameter not provided";
    if(!age) throw "age parameter not provided";
    if(!city) throw "city parameter not provided";
    if(!state) throw "state parameter not provided";

    if(typeof username != "string") throw "username parameter is not a string";
    if(typeof password != "string") throw "password parameter is not a string";
    if(typeof firstName != "string") throw "first name parameter is not a string";
    if(typeof lastName != "string") throw "last name parameter is not a string";
    if(typeof email != "string") throw "email parameter is not a string";
    if(typeof gender != "string") throw "gender parameter is not a string";
    if(typeof age != "string") throw "age parameter is not a string";
    if(typeof city != "string") throw "city parameter is not a string";
    if(typeof state != "string") throw "state parameter is not a string";

    username = username.toLowerCase();
    username = username.trim();
    password = password.trim();
    firstName = firstName.trim();
    lastName = lastName.trim();
    email = email.toLowerCase();
    email = email.trim();
    gender = gender.toUpperCase();
    gender = gender.trim();
    age = age.trim();
    city = city.toLowerCase();
    city = city.trim();
    state = state.toUpperCase();
    state = state.trim();

    if(gender !== "M" && gender !== "F" && gender !== "O") throw "invalid gender";

    if(username.length == 0) throw "username parameter is empty";
    if(password.length == 0) throw "password parameter is empty";
    if(firstName.length == 0) throw "first name parameter is empty";
    if(lastName.length == 0) throw "last name parameter is empty";
    if(email.length == 0) throw "email parameter is empty";
    if(gender.length == 0) throw "gender parameter is empty";
    if(age.length == 0) throw "age parameter is empty";
    if(city.length == 0) throw "city parameter is empty";
    if(state.length == 0) throw "state parameter is empty";

    if(email.length < 6) throw "invalid email";
    if(username.length < 4) throw "username must be at least 4 characters long";
    if(password.length < 6) throw "password must be at least 6 characters long";
    if(state.length != 2) throw "state must only be 2 characters long";
    if(gender.length != 1) throw "gender must only be 1 character long";  

    if(/\s/.test(username)) throw "username should not contain spaces"
    if(/\s/.test(password)) throw "password should not contain spaces"
    if(/\s/.test(firstName)) throw "first name should not contain spaces"
    if(/\s/.test(email)) throw "email should not contain spaces"
    if(/\s/.test(age)) throw "age should not contain spaces"
    if(/\s/.test(state)) throw "state should not contain spaces"

    var alphaNumerics = /^[0-9a-zA-Z]+$/;
    if(!username.match(alphaNumerics)) throw "username can only contain alphanumeric characters";

    for (let i = email.length - 1; i > 0; i--) {
        if (email.charAt(i) == '.') {
            if (email.charAt(i+1).length == 0 || email.charAt(i+2).length == 0) {
                throw "email does not contain two characters after ."
            }
            if (!isNaN(email.charAt(i+1)) || !isNaN(email.charAt(i+2))) {
                throw "email contains numbers after ."
            }
        }
    }

    if(!email.includes("@")) throw "invalid email address"

    let age_test = parseInt(age)
    if (age_test < 18 || age_test > 100) throw "invalid age";
}

async function errorCheckPreferences(ageMin, ageMax, gender, city) {
    if(!ageMin) throw "min age parameter not provided";
    if(!ageMax) throw "max age parameter not provided";
    if(!gender) throw "gender parameter not provided";
    if(!city) throw "city parameter not provided";

    if(typeof ageMin != "string") throw "min age parameter is not a string";
    if(typeof ageMax != "string") throw "max age parameter is not a string";
    if(typeof gender != "string") throw "gender parameter is not a string";
    if(typeof city != "string") throw "city parameter is not a string";

    gender = gender.toUpperCase();
    gender = gender.trim();
    ageMin = ageMin.trim();
    ageMax = ageMax.trim();
    city = city.toLowerCase();
    city = city.trim();

    if(gender !== "M" && gender !== "F" && gender !== "O") throw "invalid gender";

    if(gender.length == 0) throw "gender parameter is empty";
    if(ageMin.length == 0) throw "min age parameter is empty";
    if(ageMax.length == 0) throw "max age parameter is empty";
    if(city.length == 0) throw "city parameter is empty";


    if(gender.length != 1) throw "gender must only be 1 character long"; 
    if(ageMin.length > 2) throw "min age must only be 2 characters long"; 
    if(ageMax.length > 2) throw "max age must only be 2 characters long"; 

    let test_age_min = parseInt(ageMin);
    let test_age_max = parseInt(ageMax);

    if(test_age_min < 18 || test_age_min > 99) throw "invalid minimum age";
    if(test_age_max < 18 || test_age_max > 99) throw "invalid maximum age";
    if(test_age_min > test_age_max) throw "maximum age is less than the minimum age";
}

router.get('/', async (req, res) => {
    if (req.session.user) {
        return res.redirect('/loggedin');
    }
    else {
        try{
            return res.status(200).render('pages/home', {title: "Home", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.get('/aboutus', async (req, res) => {  
    if(req.session.user) {
        try{
            return res.status(200).render('pages/aboutus', {title: "About us!", username: req.session.user.username, loggedin: true});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }   
    else {
        try{
            return res.status(200).render('pages/aboutus', {title: "About us!", loggedin: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.get('/contactus', async (req, res) => {  
    if(req.session.user) {
        try{
            return res.status(200).render('pages/contactus', {title: "Contact us!", username: req.session.user.username, loggedin: true});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }   
    else {
        try{
            return res.status(200).render('pages/contactus', {title: "Contact us!", loggedin: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.get('/signup', async (req, res) => {
    if (req.session.user) {
        return res.redirect('/loggedin');
    }
    else {
        try{
            return res.status(200).render('pages/signup', {title: "Sign up",  error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.post('/signup', upload.single('photo'), async (req, res) => {
    const userDataBody = req.body;
    let user;
    let preferences;
    let final_img;
    let userId;

    try {
        await errorCheckSignUp(xss(userDataBody.username), xss(userDataBody.password), xss(userDataBody.firstName), xss(userDataBody.lastName), 
        xss(userDataBody.email), xss(userDataBody.gender), xss(userDataBody.age), xss(userDataBody.city), xss(userDataBody.state));
    } catch (e) {
        return res.status(400).render('pages/signup', {title: "Sign up", error: true, errorMessage: e});
    }

 
    try {
        let img = fs.readFileSync(req.file.path);
        let encode_img = img.toString('base64');
        final_img = {
            contentType:req.file.mimetype,
            image:new Buffer.from(encode_img,'base64')
        };
        image.create(final_img);
      } catch (e) {
        final_img = {
            contentType:"image/jpeg",
            image:"none"
        };
    }

    try {       
        user = await userData.createUser(xss(userDataBody.username), xss(userDataBody.password), xss(userDataBody.firstName), 
            xss(userDataBody.lastName), xss(userDataBody.email), xss(userDataBody.gender), xss(userDataBody.age), xss(userDataBody.city), xss(userDataBody.state), "false", final_img);
      } catch (e) {
        return res.status(400).render('pages/signup', {title: "Sign up", error: true, errorMessage: e});
    }

    try {
        userId = await userData.getUserIdFromUsername(xss(userDataBody.username));
    } catch (e) {
        return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
    }

    try {       
        preferences = await userData.setPreferences(userId, xss(userDataBody.ageMin), xss(userDataBody.ageMax), xss(userDataBody.genderpref), xss(userDataBody.citypref));
      } catch (e) {
        return res.status(400).render('pages/signup', {title: "Sign up", error: true, errorMessage: e});
    }

    try {
        if(user.userInserted == true && preferences.preferencesUpdated == true) {
            return res.redirect('/loggedin');
        }
    } catch (e) {
        return res.status(500).render('pages/error', {title: "Error", error: "Internal Server Error", username: req.session.user.username});
    }


});

router.get('/login', async (req, res) => {
    if (req.session.user) {
        return res.redirect('/loggedin');
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.post('/login', async (req, res) => {
    const userDataBody = req.body;
    
    try {
        await errorCheckLogin(xss(userDataBody.username), xss(userDataBody.password));
    } catch (e) {
        return res.status(400).render('pages/login', {title: "Log in", error: true, errorMessage: e});
    }

    try {
        const user = await userData.checkUser(xss(userDataBody.username), xss(userDataBody.password));
      } catch (e) {
        return res.status(400).render('pages/login', {title: "Log in", error: true, errorMessage: e});
    }

    try {
        const user = await userData.checkUser(xss(userDataBody.username), xss(userDataBody.password));
        if(user.authenticated == true) {
            req.session.user = {username: xss(userDataBody.username)};
            return res.redirect('/loggedin');
        }
    } catch (e) {
        return res.status(400).render('pages/login', {title: "Login", error: true, errorMessage: e});
    }
});

router.get('/loggedin', async (req, res) => {  
    if(req.session.user) {
        try{
            let userID = await users.getUserIdFromUsername(req.session.user.username);
            let curUser = await users.getUser(userID);
            if(curUser.aboutMe === ""){
                curUser.aboutMe = "You don't have an 'About me' section yet! Click below to add one.";
            }
            let min;
            let max;
            let gpref;
            let citypref;
            if(curUser.preferences === {}){
                min = 18;
                max = 100;
                gpref = 'N/A';
                citypref = 'N/A';
            }
            else{
                min = curUser.preferences.ageMin;
                max = curUser.preferences.ageMax;
                gpref = curUser.preferences.gender;
                citypref = curUser.preferences.city;
            }
            if(curUser.photo.image.toString() != "none") {
                let image_url = "data:" + curUser.photo.contentType + ";base64," + curUser.photo.image.toString('base64');
                return res.status(200).render('pages/index', {title: "Welcome!", username: req.session.user.username, photo:image_url, 
                    firstname: curUser.firstName, lastname: curUser.lastName, email: curUser.email, gender: curUser.gender, age: curUser.age, 
                    city: curUser.city, state: curUser.state, aboutMe: curUser.aboutMe, min: min, max: max, gpref: gpref, citypref: citypref, hasImage: true});
            }
            if(curUser.photo.image.toString() == "none") {
                let image_url = "data:" + curUser.photo.contentType + ";base64," + curUser.photo.image.toString('base64');
                return res.status(200).render('pages/index', {title: "Welcome!", username: req.session.user.username, photo:image_url, 
                    firstname: curUser.firstName, lastname: curUser.lastName, email: curUser.email, gender: curUser.gender, age: curUser.age, 
                    city: curUser.city, state: curUser.state, aboutMe: curUser.aboutMe, min: min, max: max, gpref: gpref, citypref: citypref, hasImage: false});
            }

        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    
});

router.get('/editprofile', async (req, res) => {
    if(req.session.user){
        try{
            return res.status(200).render('pages/updateprofile', {title: "Edit Profile", username: req.session.user.username, error: false});
        } catch(e){
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    else{
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.post('/editprofile/:username', async (req, res) => {
    const info = req.body;
    let userId;
    let user;

    try{
       await errorCheckSignUp("username", "password", xss(info.firstName), xss(info.lastName), xss(info.email), xss(info.gender), xss(info.age), xss(info.city), xss(info.state));
    } catch (e){
        return res.status(400).render('pages/updateprofile', {title: "Edit Profile", error: true, errorMessage: e, username: req.session.user.username});
    }

    try{
        userId = await userData.getUserIdFromUsername(req.params.username);
    } catch (e) {
        return res.render('pages/error', {title: "Error", error: e});
    }

    try{
        user = await userData.updateUser(userId, xss(info.firstName), xss(info.lastName), xss(info.email), xss(info.gender), xss(info.age), xss(info.city), xss(info.state));
    } catch (e){
        return res.render('pages/error', {title: "Error", error: e});
    }
    try{
        if(user == "it worked!"){
            return res.redirect('/loggedin');
        }
    } catch (e){
        return res.status(500).render('pages/error', {title: "Error", error: "Internal Server Error"});
    }
});

router.get('/aboutme', async (req, res) => {
    if(req.session.user){
        try{
            return res.status(200).render('pages/aboutme', {title: "About me", username: req.session.user.username, error: false});
        } catch(e){
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    else{
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.post('/aboutme/:username', async(req, res) =>{
    const info = xss(req.body.aboutme);
    let userId;
    let user;
    if(typeof info != 'string'){
        return res.status(400).render('pages/aboutme', {title: "Set your aboutme", username: req.session.user.username, error: true, errorMessage: "Must be a string"});
    }
    if(!info) {
        return res.status(400).render('pages/aboutme', {title: "Set your aboutme", username: req.session.user.username, error: true, errorMessage: "You must fill in the field"});
    }

    try{
        userId = await userData.getUserIdFromUsername(req.params.username);
    } catch (e) {
        return res.render('pages/error', {title: "Error", error: e});
    }

    try{
        user = await userData.updateAboutMe(userId, info);
    } catch (e){
        return res.status(400).render('pages/aboutme', {title: "Set your aboutme", username: req.session.user.username, error: true, errorMessage: e});
    }

    try {
        if(user.aboutmeUpdated == true) {
            return res.redirect('/loggedin');
        }
    } catch (e) {
        return res.status(500).render('pages/error', {title: "Error", error: "Internal Server Error"});
    }
});

router.get('/preferences', async (req, res) => {
    if(req.session.user) {
        try{
            return res.status(200).render('pages/preferences', {title: "Set your preferences", username: req.session.user.username, error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
        }
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
   
});

router.post('/preferences/:username', async (req, res) => {  
    const userPrefBody = req.body;
    let userId;
    let user;

    if(req.session.user) {
        try {
            await errorCheckPreferences(xss(userPrefBody.ageMin), xss(userPrefBody.ageMax), xss(userPrefBody.gender), xss(userPrefBody.city));
        } catch (e) {
            return res.status(400).render('pages/preferences', {title: "Set your preferences", username: req.session.user.username, error: true, errorMessage: e});
        }

        try {
            userId = await userData.getUserIdFromUsername(req.params.username);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
        }

        try {
            user = await userData.setPreferences(userId, xss(userPrefBody.ageMin), xss(userPrefBody.ageMax), xss(userPrefBody.gender), xss(userPrefBody.city));
        } 
        catch (e) {
            return res.status(400).render('pages/preferences', {title: "Set your preferences", username: req.session.user.username, error: true, errorMessage: e});
        }

        try {
            if(user.preferencesUpdated == true) {
                return res.redirect('/loggedin');
            }
        } catch (e) {
            return res.status(500).render('pages/error', {title: "Error", error: "Internal Server Error", username: req.session.user.username});
        }
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.get('/swiping/:username', async (req, res) => {  
    let userId;
    let usersToShow;
    let aboutMe = true;


    if(req.session.user) {
        try {
            userId = await userData.getUserIdFromUsername(req.params.username);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
        }
    
        try {
            usersToShow = await userData.getAllUsersBasedOnPreferences(userId);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
        }
    
        try{
            if(usersToShow.length > 0) {
                if(usersToShow[0].aboutMe == "") {
                    aboutMe = false;
                }
                if(usersToShow[0].photo.image == "none") {
                    return res.status(200).render('pages/swiping', {title: "Swiping!", username: req.session.user.username, user: usersToShow[0], isUsers: true, hasImage: false, user_aboutme: aboutMe});
                }
                else {
                    let image_url = "data:" + usersToShow[0].photo.contentType + ";base64," + usersToShow[0].photo.image.toString('base64');
                    return res.status(200).render('pages/swiping', {title: "Swiping!", username: req.session.user.username, user: usersToShow[0], isUsers: true, hasImage: true, photo:image_url, user_aboutme: aboutMe});
                }       
            }
            else {
                return res.status(200).render('pages/swiping', {title: "Swiping!", username: req.session.user.username, user: usersToShow[0], isUsers: false});
            }
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }

    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    
});

router.get('/report/:usernameOne/:usernameTwo' , async (req, res) =>{
    let userId;
    let response;

    if(req.session.user) {
        try {
            userId = await userData.getUserIdFromUsername(req.params.usernameTwo);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.username});
        }
        try{
            response = await userData.report(userId);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
        try{
            let newLink = "/swiping/" + req.params.usernameOne;
            return res.redirect(newLink);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }

    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
    
})

router.get('/like/:usernameOne/:usernameTwo', async (req, res) => { 
    let response; 
    let userOneId;
    let userTwoId;

    if(req.session.user) {
        try {
            userOneId = await userData.getUserIdFromUsername(req.params.usernameOne);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.usernameOne});
        }

        try {
            userTwoId = await userData.getUserIdFromUsername(req.params.usernameTwo);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.usernameTwo});
        }

        try{
            response = await userData.like(userOneId, userTwoId);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
        
        try{
            let newLink = "/swiping/" + req.params.usernameOne;
            return res.redirect(newLink);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
        
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
    }
});

router.get ('/dislike/:usernameOne/:usernameTwo', async (req, res) => {  
    if(req.session.user) {
        try {
            userOneId = await userData.getUserIdFromUsername(req.params.usernameOne);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.usernameOne});
        }

        try {
            userTwoId = await userData.getUserIdFromUsername(req.params.usernameTwo);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e, username: req.session.user.usernameTwo});
        }

        try{
            response = await userData.dislike(userOneId, userTwoId);
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: e});
        }
        
        if(response.noMatch == true) {
            let newLink = "/swiping/" + req.params.usernameOne;
            return res.redirect(newLink);
        }
        else {
            return res.render('pages/error', {title: "Error", error: "Error"});
        }
    }
    else {
        try{
            return res.status(200).render('pages/login', {title: "Login", error: false});
        } catch (e) {
            return res.render('pages/error', {title: "Error", error: "Error"});
        }
    }
});

router.get('/logout', async (req, res) => {
    req.session.destroy();
    try {
        return res.status(200).render('pages/home', {title: "Home", error: false});
    }
    catch(e) {
        return res.render('pages/error', {title: "Error", error: "Error"});
    }
});

module.exports = router;