(function ($) {

	$('#contact-form').submit(function (e) {
        e.preventDefault();
        var request = {
			method: $('#contact-form').attr('method'),
			url: $('#contact-form').attr('action')
		};
		$.ajax(request).then(function(responseMessage) {
            if($('#contact-name').val() && $('#contact-email').val() && $('#message').val() && $('#message').val()) {
                alert("Your form was submitted")
                window.location.href = "/loggedin";
                return false;
            }
            else {
                alert("Your form was not submitted. Please fill all fields")
            }

        });
    });

	$('#edit-profile-button').on('click', function (event) {
		event.preventDefault(); 
		window.location.href = "/editprofile"
	});

	$('#edit-aboutme-button').on('click', function (event) {
		event.preventDefault(); 
		window.location.href = "/aboutme"
	});

	$('#edit-prefs-button').on('click', function (event) {
		event.preventDefault(); 
		window.location.href = "/preferences"
	});

	$('#like').on('click', function (event) {
		event.preventDefault(); 
		$('#usernameOne').hide();
		$('#usernameTwo').hide();
		window.location.href = "/like" + "/" +  $('#usernameOne').html() + "/" +  $('#usernameTwo').html();
		return false;
	});

	$('#dislike').on('click', function (event) {
		event.preventDefault(); 
		$('#usernameOne').hide();
		$('#usernameTwo').hide();
		window.location.href = "/dislike" + "/" +  $('#usernameOne').html() + "/" +  $('#usernameTwo').html();
		return false;
	});

	$('#report').on('click', function (event) {
		event.preventDefault()
		let txt;
		if (confirm("Are you sure you want to report this person?")) {
			txt = "true";
			alert("You have reported this person.")
			window.location.href = "/report" + "/" +  $('#usernameOne').html() + "/" +  $('#usernameTwo').html()
		}
	});

})(window.jQuery);