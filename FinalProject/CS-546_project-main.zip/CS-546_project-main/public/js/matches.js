function fetchChatFunc(userId,userImage, matchImage, matchId){
    
    $.post("../fetchChat",
        {
          userId: userId,
          matchId: matchId
        }, function(data, status, jqXHR) {// success callback
            var messagesDisp = $('.messages');
            messagesDisp.empty();
            //console.log(data);
            $(".message-window").data("data-chatroomId", data.chatroomId);
            
            for(let i = 0; i < data.chats.length; i++){
                let curchat = data.chats[i];
                let newclass = (curchat.sender == userId) ? "sentMessage" : "recievedMessage"

                var newmessage = $("<div></div>", {class: "message"});
                var containerdiv = $("<div></div", {class: "paired-container "+ newclass+"c"});
                let time = new Date(curchat.time).toLocaleString();
                var newp = $("<p></p>", {text: curchat.chat,class: newclass, "data-toggle":"tooltip", title:time});
                var newimcont = $('<div></div', {class: "icon-container"})
                
                if(newclass == "sentMessage"){
                    var newimg = $('<img>', {class:"message-icon", src:userImage});
                    newimcont.append(newimg);
                    containerdiv.append(newp);
                    containerdiv.append(newimcont);
                }else{
                    var newimg = $('<img>', {class:"message-icon", src:matchImage});
                    newimcont.append(newimg);
                    containerdiv.append(newimcont);
                    containerdiv.append(newp);
                }
                newmessage.append(containerdiv);
                messagesDisp.append(newmessage);
            }
            
            
            messagesDisp.scrollTop(messagesDisp[0].scrollHeight);

        });
}


$(function () {
    $(".message-window").hide();
    const userImage = $(".message-window").attr("data-userImage");
    const userId = $(".matches-list").attr("data-id");
    //console.log(userId);
    
    const refreshButton = $('.refreshButton');
    refreshButton.on("click", (e) =>{
        let matchId = $("#message-title").data("matchId");
        let matchImage = $("#head-image").attr('src');
        fetchChatFunc(userId, userImage,matchImage,matchId);
    })
    $('#chatsend').on("click", (e) => {
        //console.log("form submitted");
        let chatroomId = $(".message-window").data("data-chatroomId");
        //console.log(chatroomId);
        let text = $("#chatbox").val()
        if(text.trim().length > 0){
            $.post("/sendChat", 
            {   
                message:text,
                chatroom: chatroomId,
                userId: userId

            },  function(data, status, jqXHR) {// success callback
                //console.log("done");
             });
        }
        $('#chatbox').val("");
        refreshButton.click();
        e.preventDefault();
    })
    
    
    $( ".match-item" ).click(function() {
        $(".message-window").show();
        //console.log("clicked");
        let imagesrc = $(this).find('img').attr('src');
        let matchId = $(this).attr("data-matchid");
        // $(".message-window").show()
        let headimage = $("#head-image").attr('src', imagesrc);
        let headTitle = $("#message-title")
        headTitle.text($(this).text());
        headTitle.data("matchId", matchId);



        fetchChatFunc(userId, userImage,imagesrc,matchId);
    });
    

    $(".chatForm").submit((e)=>{
        e.preventDefault();
        $("#chatsend").click();
        
    })
});

