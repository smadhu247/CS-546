const userData = require('./users');
const messageData = require('./messages');

module.exports = {
  users: userData,
  messages: messageData
};
