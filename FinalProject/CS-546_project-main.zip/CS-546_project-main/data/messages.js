const { ObjectId } = require('mongodb');
const mongoCollections = require('../config/mongoCollections');
const messages = mongoCollections.messages;
const {users, chatroom} = mongoCollections;

function validateString(s){
    if(!s || typeof s != "string"){ return "invalid string" }
    if(s.trim().length === 0){ return "empty string" }
    return false
}


exports.getMatchPreviews = async (userId) => {

    //validate userId
    if (!ObjectId.isValid(userId)) throw 'Error: invalid userID';

    const userCollection = await users();

    const user = await userCollection.findOne({ _id: ObjectId(userId) }, { projection: {matches: true} });
    if (user === null) throw 'Error: No user with that id';
    // //console.log(user);

    // this will be the data we will take from each user for the preview:
    // we may want to take images in the future (after images are working)
    projection= {
        firstName: true,
        lastName: true,
        photo: true
    }
    const previews = [];
    for(let i = 0; i < user.matches.length; i++) {
        let cur = await userCollection.findOne( {_id: ObjectId(user.matches[i]) }, { projection: projection });
        if(cur === null){
            console.error("No user with the id " + user.matches[i]);
            continue;
        };
        previews.push( cur );
    }

    return previews;
}




createChatroom = async (person1Id, person2Id) =>{
    // //console.log("creating chatroom");
    if (!ObjectId.isValid(person1Id) || !ObjectId.isValid(person2Id)) throw 'Error: invalid personId';
    const chatCollection = await chatroom();

    let newChatroom = {
        "profileOneId": person1Id,
        "profileTwoId": person2Id,
        "messages": []
    }
    const insertInfo = await chatCollection.insertOne(newChatroom);
    if (!insertInfo.acknowledged || !insertInfo.insertedId){
        throw 'Error: Could not create chatroom';
    }
    const newId = insertInfo.insertedId.toString();

    const userCollection = await users();

    let updateInfoOne = await userCollection.updateOne(
        { _id: ObjectId(person1Id) },
        {
            $push: {messageRooms : newId},
        }

    );
    let updateInfoTwo = await userCollection.updateOne(
        { _id: ObjectId(person2Id) },
        {
            $push: {messageRooms : newId},
        }

    );
    if(updateInfoOne.modifiedCount === 0){
        console.error("chatroom was not added to list of: " + person1Id)
    }
    if(updateInfoTwo.modifiedCount === 0){
        console.error("chatroom was not added to list of: " + person2Id)
    }
    if(updateInfoOne.modifiedCount === 0 || updateInfoTwo.modifiedCount === 0){
        throw "Error: At least one account was not able to be updated with new chatroom"
    }
    
    return newId;
}

exports.findChatroom = async (userId, matchId) =>{
    if (!ObjectId.isValid(userId) || !ObjectId.isValid(matchId)) throw 'Error: invalid personId';
    const userCollection = await users();

    const user = await userCollection.findOne({ _id: ObjectId(userId) }, { projection: {messageRooms: true} });
    if (user === null) throw 'Error: No user with that id';

    // //console.log(user.messageRooms);
    if(user.messageRooms.length === 0){
        return await createChatroom(userId, matchId);
    }

    const chatCollection = await chatroom();
    for(let i = 0; i < user.messageRooms.length; i++){
        chatroomId = user.messageRooms[i];
        // //console.log(chatroomId);
        const try1 = await chatCollection.findOne( {profileOneId: userId, profileTwoId: matchId}, {projection: {_id:true}} );
        if (try1 === null){
            const try2 = await chatCollection.findOne( {profileOneId: matchId, profileTwoId: userId}, {projection: {_id:true}} );
            if ( try2 === null ){
                continue;
            }
            //else
            return try2._id;
        }
        return try1._id;
    }
    return await createChatroom(userId, matchId);
}

exports.createMessage = async (text, chatroomId, senderId) =>{
    // //console.log("creating message");
    if (!ObjectId.isValid(chatroomId)) throw 'Error: invalid chatroomId';
    // //console.log(text);
    // //console.log(validateString(text));
    if(validateString(text)){ return; }
    if (!ObjectId.isValid(senderId)) throw 'Error: invalid senderId';
    // //console.log("checks passed");
    let newMessage = {
        // "messageRoomId": person1Id,  we may want this, not sure yet
        "_id": ObjectId(),
        "sender": senderId,
        "chat": text,
        "time": new Date()
    }

    const chatCollection = await chatroom();

    const feedback = await chatCollection.updateOne(
        {_id: ObjectId(chatroomId)},
        { "$push": {"messages": newMessage} }
    )
    if(feedback.modifiedCount === 0){
        throw "no update made"
    }

    return newMessage._id;
}


exports.getMessageHistory = async (chatroomId) =>{
    if (!ObjectId.isValid(chatroomId)) throw 'Error: invalid chatroomId';
    const chatCollection = await chatroom();
    
    const chat = await chatCollection.findOne({_id: ObjectId(chatroomId)}, { projection: {messages: true} });
    if (chat === null) throw 'Error: No chatroom with that id';

    return chat.messages;

}

exports.getImage = async (userId) =>{
    if (!ObjectId.isValid(userId)) throw 'Error: invalid personId';
    const userCollection = await users();
    const user = await userCollection.findOne({ _id: ObjectId(userId) }, { projection: {photo: true} });
    if (user === null) throw 'Error: No user with that id';
    return user.photo;
}

