const mongoCollections = require('../config/mongoCollections');
const users = mongoCollections.users;
const bcrypt = require ('bcrypt');
const { ObjectId } = require('mongodb');
const { get } = require('express/lib/request');
const saltRounds = 12;

async function createUser(username, password, firstName, lastName, email, gender, age, city, state, report, photo) {

    if(!username) throw "username parameter not provided";
    if(!password) throw "password parameter not provided";
    if(!firstName) throw "first name parameter not provided";
    if(!lastName) throw "last name parameter not provided";
    if(!email) throw "email parameter not provided";
    if(!gender) throw "first name parameter not provided";
    if(!age) throw "last name parameter not provided";
    if(!city) throw "email parameter not provided";
    if(!state) throw "first name parameter not provided";

    if(!photo) {
        photo = {
            contentType:"image/jpeg",
            image:"none"
        };
    }

    if(typeof username != "string") throw "username parameter is not a string";
    if(typeof password != "string") throw "password parameter is not a string";
    if(typeof firstName != "string") throw "first name parameter is not a string";
    if(typeof lastName != "string") throw "last name parameter is not a string";
    if(typeof email != "string") throw "email parameter is not a string";
    if(typeof gender != "string") throw "gender parameter is not a string";
    if(typeof age != "string") throw "age parameter is not a string";
    if(typeof city != "string") throw "city parameter is not a string";
    if(typeof state != "string") throw "state parameter is not a string";

    username = username.toLowerCase();
    username = username.trim();
    password = password.trim();
    firstName = firstName.trim();
    lastName = lastName.trim();
    email = email.toLowerCase();
    email = email.trim();
    gender = gender.toUpperCase();
    gender = gender.trim(); 
    age = age.trim();
    city = city.toLowerCase();
    city = city.trim();
    state = state.toUpperCase();
    state = state.trim();
    report = false;

    if(gender !== "M" && gender !== "F" && gender !== "O") throw "invalid gender";

    if(username.length == 0) throw "username parameter is empty";
    if(password.length == 0) throw "password parameter is empty";
    if(firstName.length == 0) throw "first name parameter is empty";
    if(lastName.length == 0) throw "last name parameter is empty";
    if(email.length == 0) throw "email parameter is empty";
    if(gender.length == 0) throw "gender parameter is empty";
    if(age.length == 0) throw "age parameter is empty";
    if(city.length == 0) throw "city parameter is empty";
    if(state.length == 0) throw "state parameter is empty";

    if(email.length < 6) throw "invalid email";
    if(username.length < 4) throw "username must be at least 4 characters long";
    if(password.length < 6) throw "password must be at least 6 characters long";
    if(state.length != 2) throw "state must only be 2 characters long";
    if(gender.length != 1) throw "gender must only be 1 character long";  

    if(/\s/.test(username)) throw "username should not contain spaces"
    if(/\s/.test(password)) throw "password should not contain spaces"
    if(/\s/.test(firstName)) throw "username should not contain spaces"
    if(/\s/.test(email)) throw "password should not contain spaces"
    if(/\s/.test(age)) throw "username should not contain spaces"
    if(/\s/.test(state)) throw "password should not contain spaces"

    var alphaNumerics = /^[0-9a-zA-Z]+$/;
    if(!username.match(alphaNumerics)) throw "username can only contain alphanumeric characters";

    for (let i = email.length - 1; i > 0; i--) {
        if (email.charAt(i) == '.') {
            if (email.charAt(i+1).length == 0 || email.charAt(i+2).length == 0) {
                throw "email does not contain two characters after ."
            }
            if (!isNaN(email.charAt(i+1)) || !isNaN(email.charAt(i+2))) {
                throw "email contains numbers after ."
            }
        }
    }

    if(!email.includes("@")) throw "invalid email address"


    let age_test = parseInt(age)
    if (age_test < 18 || age_test > 100) throw "invalid age";

    const usersCollection = await users();
    const user_username = await usersCollection.findOne({ username: username });
    if (user_username !== null) throw 'there already a user with that username';

    const user_email = await usersCollection.findOne({ email: email });
    if (user_email !== null) throw 'there already a user with that email';

    const hashedPassword = await bcrypt.hash(password, saltRounds);

    let newUser = {
        username: username,
        password: hashedPassword,
        firstName: firstName,
        lastName: lastName,
        email: email, 
        gender: gender, 
        age: age, 
        city: city, 
        state: state, 
        report: report,
        preferences: {}, 
        aboutMe: "",
        matches: [], 
        seen_users: [],
        liked_users: [],
        messageRooms: [],
        photo: photo
    };

    const insertInfo = await usersCollection.insertOne(newUser);
    if (insertInfo.insertedCount === 0) throw 'could not add user to the database';

    let obj = {userInserted: true}
    return obj;
}

async function checkUser(username, password){

    if(!username) throw "username parameter not provided";
    if(!password) throw "password parameter not provided";

    if(typeof username != "string") throw "username parameter is not a string";
    if(typeof password != "string") throw "password parameter is not a string";

    username = username.toLowerCase();
    username = username.trim();
    password = password.trim();

    if(username.length == 0) throw "username parameter is empty";
    if(password.length == 0) throw "password parameter is empty";

    if(username.length < 4) throw "username must be at least 4 characters long";
    if(password.length < 6) throw "password must be at least 6 characters long";

    if(/\s/.test(username)) throw "username should not contain spaces"
    if(/\s/.test(password)) throw "password should not contain spaces"

    var alphaNumerics = /^[0-9a-zA-Z]+$/;
    if(!username.match(alphaNumerics)) throw "username can only contain alphanumeric characters";

    const usersCollection = await users();
    const user = await usersCollection.findOne({ username: username });
    if (user === null) throw "Either the username or password is invalid";

    let compare = false;
    try {
        compare = await bcrypt.compare(password, user.password);
    } catch (e) {
        throw "error in hashed password";
    }
  
    if (compare) {
        return {authenticated: true};
    } 
    else {
        throw "Either the username or password is invalid";
    }

}

async function getAllUsers() {
    const usersCollection = await users();
    const userList = await usersCollection.find({ }).toArray();

    for(let i = 0; i < userList.length; i++) {
        let id = userList[i]._id.toString();
        userList[i]._id = id.toString();
    }

    return userList;
}

async function getUser(userId) {

    if(!userId) throw "userId parameter not provided";
    if(typeof userId != "string") throw "userId is not a string";
    userId = userId.trim();
    if(userId.length == 0) throw "userId is an empty string";

    if(!ObjectId.isValid(userId)) throw "userId provided is not a valid ObjectId";

    const usersCollection = await users();
    const user = await usersCollection.findOne({ _id: ObjectId(userId) });
    if (user === null) throw 'No user with that id';
    user._id = user._id.toString();
    return user;
}

async function getUserIdFromUsername(username) {

    if(!username) throw "username parameter not provided";
    if(typeof username != "string") throw "username is not a string";
    username = username.trim();
    username = username.toLowerCase();
    if(username.length == 0) throw "username is an empty string";

    const usersCollection = await users();
    const user = await usersCollection.findOne({ username: username });
    if (user === null) throw 'No user with that username';

    let userId = user._id.toString();

    return userId;
}

async function removeUser(userId) {
    if(!userId) throw "userId parameter not provided";
    if(typeof userId != "string") throw "userId is not a string";
    userId = userId.trim();
    if(userId.length == 0) throw "userId is an empty string";

    if(!ObjectId.isValid(userId)) throw "userId provided is not a valid ObjectId";

    const usersCollection = await users();

    const user = await this.get(userId);
    let username = user.username;

    const deletionInfo = await usersCollection.deleteOne({ _id: ObjectId(userId) });

    if (deletionInfo.deletedCount === 0) {
      throw `Could not delete band with id of ${userId}`;
    }

    return username + " has been successfully deleted!"; 
}

async function updateUser(userId, firstName, lastName, email, gender, age, city, state) {

    if(!firstName) throw "first name parameter not provided";
    if(!lastName) throw "last name parameter not provided";
    if(!email) throw "email parameter not provided";
    if(!gender) throw "first name parameter not provided";
    if(!age) throw "last name parameter not provided";
    if(!city) throw "email parameter not provided";
    if(!state) throw "first name parameter not provided";

    if(typeof firstName != "string") throw "first name parameter is not a string";
    if(typeof lastName != "string") throw "last name parameter is not a string";
    if(typeof email != "string") throw "email parameter is not a string";
    if(typeof gender != "string") throw "gender parameter is not a string";
    if(typeof age != "string") throw "age parameter is not a string";
    if(typeof city != "string") throw "city parameter is not a string";
    if(typeof state != "string") throw "state parameter is not a string";

    if(gender !== "M" && gender !== "F" && gender !== "O") throw "invalid gender";

    firstName = firstName.trim();
    lastName = lastName.trim();
    email = email.toLowerCase();
    email = email.trim();
    gender = gender.toUpperCase();
    gender = gender.trim(); 
    age = age.trim();
    city = city.toLowerCase();
    city = city.trim();
    state = state.toUpperCase();
    state = state.trim();

    if(firstName.length == 0) throw "first name parameter is empty";
    if(lastName.length == 0) throw "last name parameter is empty";
    if(email.length == 0) throw "email parameter is empty";
    if(gender.length == 0) throw "gender parameter is empty";
    if(age.length == 0) throw "age parameter is empty";
    if(city.length == 0) throw "city parameter is empty";
    if(state.length == 0) throw "state parameter is empty";

    if(email.length < 6) throw "invalid email";
    if(state.length != 2) throw "state must only be 2 characters long";
    if(gender.length != 1) throw "gender must only be 1 character long";  

    if(/\s/.test(firstName)) throw "username should not contain spaces"
    if(/\s/.test(email)) throw "password should not contain spaces"
    if(/\s/.test(age)) throw "username should not contain spaces"
    if(/\s/.test(state)) throw "password should not contain spaces"

    for (let i = email.length - 1; i > 0; i--) {
        if (email.charAt(i) == '.') {
            if (email.charAt(i+1).length == 0 || email.charAt(i+2).length == 0) {
                throw "email does not contain two characters after ."
            }
            if (!isNaN(email.charAt(i+1)) || !isNaN(email.charAt(i+2))) {
                throw "email contains numbers after ."
            }
        }
    }

    if(!email.includes("@")) throw "invalid email address"


    let age_test = parseInt(age)
    if (age_test < 18 || age_test > 100) throw "invalid age";

    const usersCollection = await users();
    const updatedPostData = {};

    updatedPostData.firstName = firstName;
    updatedPostData.lastName = lastName;
    updatedPostData.email = email;
    updatedPostData.gender = gender;
    updatedPostData.age = age;
    updatedPostData.city = city;
    updatedPostData.state = state;

    await usersCollection.updateOne({ _id: ObjectId(userId) }, { $set: updatedPostData });

    return "it worked!";
}

async function setPreferences(userId, ageMin, ageMax, gender, city) {
    if(!ageMin) throw "min age parameter not provided";
    if(!ageMax) throw "max age parameter not provided";
    if(!gender) throw "gender parameter not provided";
    if(!city) throw "city parameter not provided";

    if(typeof ageMin != "string") throw "min age parameter is not a string";
    if(typeof ageMax != "string") throw "max age parameter is not a string";
    if(typeof gender != "string") throw "gender parameter is not a string";
    if(typeof city != "string") throw "city parameter is not a string";

    gender = gender.toUpperCase();
    gender = gender.trim();
    ageMin = ageMin.trim();
    ageMax = ageMax.trim();
    city = city.toLowerCase();
    city = city.trim();

    if(gender !== "M" && gender !== "F" && gender !== "O") throw "invalid gender";

    if(gender.length == 0) throw "gender parameter is empty";
    if(ageMin.length == 0) throw "min age parameter is empty";
    if(ageMax.length == 0) throw "max age parameter is empty";
    if(city.length == 0) throw "city parameter is empty";

    if(gender.length != 1) throw "gender must only be 1 character long"; 
    if(ageMin.length > 2) throw "min age must only be 2 characters long"; 
    if(ageMax.length > 2) throw "max age must only be 2 characters long"; 

    let test_age_min = parseInt(ageMin);
    let test_age_max = parseInt(ageMax);

    if(test_age_min < 18 || test_age_min > 99) throw "invalid minimum age";
    if(test_age_max < 18 || test_age_max > 99) throw "invalid maximum age";
    if(test_age_min > test_age_max) throw "maximum age is less than the minimum age";

    let new_preferences = {
        ageMin: ageMin,
        ageMax: ageMax,
        gender: gender,
        city: city,
    };

    const usersCollection = await users();
    await usersCollection.updateOne({ _id: ObjectId(userId) }, { $set:{ preferences: new_preferences } });

    let obj = {preferencesUpdated: true}
    return obj;
}

async function like(userOneId, userTwoId) {

    if(!userOneId) throw "userId one parameter not provided";
    if(typeof userOneId != "string") throw "userId one is not a string";
    userOneId = userOneId.trim();
    if(userOneId.length == 0) throw "userId one is an empty string";
    if(!ObjectId.isValid(userOneId)) throw "userId one provided is not a valid ObjectId";

    if(!userTwoId) throw "userId two parameter not provided";
    if(typeof userTwoId != "string") throw "userId two is not a string";
    userTwoId = userTwoId.trim();
    if(userTwoId.length == 0) throw "userId two is an empty string";
    if(!ObjectId.isValid(userTwoId)) throw "userId two provided is not a valid ObjectId";
    
    const usersCollection = await users();
    const userTwo = await usersCollection.findOne({ _id: ObjectId(userTwoId) });

    await usersCollection.updateOne({ _id: ObjectId(userOneId) }, { $addToSet: { liked_users: userTwoId } });
    await usersCollection.updateOne({ _id: ObjectId(userOneId) }, { $addToSet: { seen_users: userTwoId } });

    let userTwoLikedUserList = userTwo.liked_users;
    let matched = false;
    for(let i = 0; i < userTwoLikedUserList.length; i++) {
        if (userTwoLikedUserList[i] == userOneId) {
            matched = true;
            break;
        }
    }

    if(matched) {
        await usersCollection.updateOne({ _id: ObjectId(userOneId) }, { $addToSet: { matches: userTwoId } });
        await usersCollection.updateOne({ _id: ObjectId(userTwoId) }, { $addToSet: { matches: userOneId } });
        return {matched: true};
    }

    return {matched: false};

}

async function dislike(userOneId, userTwoId) {

    if(!userOneId) throw "userId one parameter not provided";
    if(typeof userOneId != "string") throw "userId one is not a string";
    userOneId = userOneId.trim();
    if(userOneId.length == 0) throw "userId one is an empty string";
    if(!ObjectId.isValid(userOneId)) throw "userId one provided is not a valid ObjectId";

    if(!userTwoId) throw "userId two parameter not provided";
    if(typeof userTwoId != "string") throw "userId two is not a string";
    userTwoId = userTwoId.trim();
    if(userTwoId.length == 0) throw "userId two is an empty string";
    if(!ObjectId.isValid(userTwoId)) throw "userId two provided is not a valid ObjectId";

    const usersCollection = await users();

    await usersCollection.updateOne({ _id: ObjectId(userOneId) }, { $addToSet: { seen_users: userTwoId } });

    return {noMatch: true};
}

async function getAllUsersBasedOnPreferences(userId) {
    const usersCollection = await users();
    const user = await usersCollection.findOne({ _id: ObjectId(userId) });
    let preferences = user.preferences;
    let seen_users = user.seen_users;

    let userList = await this.getAllUsers();

    let usersToShow = [];

    for(let i = 0; i < userList.length; i++) {
        if(userList[i].age >= preferences.ageMin && userList[i].age <= preferences.ageMax 
            && userList[i].gender == preferences.gender && userList[i].preferences.city == preferences.city) {
                if(userList[i]._id.toString() != userId) {
                    usersToShow.push(userList[i]);
                }
        }
    }

    for(let j = 0; j < usersToShow.length; j++) {
        for (let k = 0; k < seen_users.length; k++) {
            if(seen_users[k].toString() == usersToShow[j]._id.toString()) {
                usersToShow.splice(j, 1);
            }
        }
    }

    return usersToShow;
}

async function report(userOneId){
    const usersCollection = await users();
    await usersCollection.updateOne({ _id: ObjectId(userOneId) }, {$set:{ report: true }});
}

async function updateAboutMe(userId, info){
    if(!info) throw "info is empty";
    if(typeof info != 'string') throw "info must be a string";

    const usersCollection = await users();
    await usersCollection.updateOne({ _id: ObjectId(userId) }, {$set:{ aboutMe: info }});

    let obj = {aboutmeUpdated: true};
    return obj;
}

module.exports = {
    report,
    checkUser,
    createUser,
    getAllUsers,
    getUser,
    getUserIdFromUsername,
    removeUser,
    updateUser,
    setPreferences,
    like,
    dislike,
    getAllUsersBasedOnPreferences,
    updateAboutMe
}