const dbConnection = require('../config/mongoConnection');
const data = require('../data/');
const users = data.users;

async function main(){
    const db = await dbConnection();
    await db.dropDatabase();

    const userOne = await users.createUser("jnaeher", "password", "Jake", "Naeher", "jnaeher@stevens.edu", "m", "21", "Hoboken", "NJ");
    const ids = []
    var id;
    ids.push(id=await users.getUserIdFromUsername("jnaeher"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userTwo = await users.createUser("smadhu", "123456", "Sanjana", "Madhu", "smadhu@stevens.edu", "f", "20", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("smadhu"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userThree = await users.createUser("fshaik", "dogcat", "Farhan", "Shaik", "fshaik@stevens.edu", "M", "20", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("fshaik"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userFour = await users.createUser("jrossi", "csrocks", "Jason", "Rossi", "jrossi3@stevens.edu", "M", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("jrossi"));
    await users.setPreferences(id, "18", "30",  "F","Hoboken");

    const userFive = await users.createUser("jdoe", "welovewebprogramming", "John", "Doe", "jdoe@gmail.com", "O", "23", "New York", "NY");
    ids.push(id=await users.getUserIdFromUsername("jdoe"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userSix = await users.createUser("phill", "bestprof", "Patrick", "Hill", "phill@stevens.edu", "O", "25", "New York City", "NY");
    ids.push(id=await users.getUserIdFromUsername("phill"));
    const phillid = id;
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userSeven = await users.createUser("user1", "password", "One", "Smith", "userone@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user1"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userEight = await users.createUser("user2", "password", "Two", "Smith", "usertwo@stevens.edu", "M", "23", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user2"));
    await users.setPreferences(id, "18", "30",  "F","Hoboken");

    const userNine = await users.createUser("user3", "password", "Three", "Smith", "userthree@stevens.edu", "F", "20", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user3"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userTen = await users.createUser("user4", "password", "Four", "Smith", "userfour@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user4"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userEleven = await users.createUser("user5", "password", "Five", "Smith", "userfive@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user5"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userTwelve = await users.createUser("user6", "password", "Six", "Smith", "usersix@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user6"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userThirteen = await users.createUser("user7", "password", "Seven", "Smith", "userseven@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user7"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userFourteen = await users.createUser("user8", "password", "Eight", "Smith", "usereight@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user8"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userFifteen = await users.createUser("user9", "password", "Nine", "Smith", "usernine@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user9"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userSixteen = await users.createUser("user10", "password", "Ten", "Smith", "userten@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user10"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userSeventeen = await users.createUser("user11", "password", "Eleven", "Smith", "usereleven@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user11"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userEighteen = await users.createUser("user12", "password", "Twelve", "Smith", "usertwelve@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user12"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userNineteen = await users.createUser("user13", "password", "Thirteen", "Smith", "userthirteen@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user13"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");

    const userTwenty = await users.createUser("user14", "password", "Fourteen", "Smith", "userfourteen@stevens.edu", "F", "21", "Hoboken", "NJ");
    ids.push(id=await users.getUserIdFromUsername("user14"));
    await users.setPreferences(id, "18", "30", "F", "Hoboken");
    // console.log(id)
    console.log("Done seeding the database");

    // console.log(ids);
    // console.log(phillid);
    for(let i = 6; i < ids.length; i++){
        // console.log()
        await users.like(ids[i], phillid);
    }


    await db.s.client.close();
}

main();