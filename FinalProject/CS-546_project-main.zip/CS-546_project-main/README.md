# FiNDR
_I pledge my honor I have abided by the Stevens Honor System_

- Table of Contents
  * [Team members](#team-members)
  * [Synopsis](#synopsis)
  * [To Run](#to-run)
  * [Core Features](#core-features)
  * [Extra Features](#extra-features)

## Team members:
  - Farhan Shaik
  - Sanjana Madhu
  - Jacob Naeher
  - Jason Rossi

## Synopsis:
>  Our project will be a roommate matching web application. To start, the user will be taken to a landing page that is essentially a tutorial on how the web app functions. Each user will create their own profile with various sections that inform other users who they are and what they enjoy. This web app will allow users to see other users’ profiles and determine if they are interested in being roommates with them. There will be a filtering feature that gives the user a higher chance of matching with someone with common interests. When it comes down to the actual usage of the app, users will access a page that randomly generates other peoples’ profiles from where the user likes or dislikes the profile to determine whether or not they are interested in being roommates. If the user likes a profile and the other person likes the user back, both people will find each other in their matches page. From here they can start messaging.

## To Run:

in shell:
  
    git clone https://github.com/FarhanShaik/CS-546_project.git
    cd CS-546_project
    npm install
    npm run seed
    npm start


## Core Features
1. User Profile: each user will create a profile complete with their picture, name age, gender, location, preferred pronouns, number of roommates they are looking for, and housing preferences
2. Landing Page: explains the functionalities of the website the features offered
3. Swiping Page: shows one possible roommate at a time and allows the user to “like” or “dislike” other users based on their profile 
4. Filtering profiles: the user can select their preferences in a roommate and will only be shown users who fit those criteria
5. Matches Page: shows all the potential roommates that the user has matched with 
6. Algorithm that allows people to be matches together
7. A messaging feature that allows users to communicate with one another!

## Extra Features
- Additional attributes for profiles where users can share a bio about themselves
- Verifying if they are a Stevens student (@stevens.edu email)
- Reporting other users



